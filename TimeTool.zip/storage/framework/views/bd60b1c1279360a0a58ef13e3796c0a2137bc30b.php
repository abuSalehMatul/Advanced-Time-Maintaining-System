<!DOCTYPE html>

<head>
 
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <title>The TimeREC</title> 
  <link rel="shortcut icon" href="<?php echo e(asset('image/REC-Icon2.png')); ?>" type="image/x-icon">

  <link rel='stylesheet' href=<?php echo e(asset('css/main-012.css')); ?>>
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  
    <?php echo $__env->make('partials.frontCSS', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
</head>
<style>
    #id{
        background-image:url('/../image/Logo 2 .png');
    }
</style>
<body>
   
    
    <div id="app">
       
        

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
