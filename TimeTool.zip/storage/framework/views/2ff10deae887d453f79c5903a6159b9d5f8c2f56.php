<?php $__env->startSection('content'); ?>
    <div class="card" style="margin-left:5px">
        <div class="well"> 
            <form action="<?php echo e(url('add_category')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group" >
                    <label for="" style="border:1px solid blue; box-shadow:1px 1px orange;font-size:1.2rem;font-weight:600">
                        Name of the category
                    </label>
                    <input type="text" style="display:block;padding:5px" class="" name="category_name" placeholder="ex. IT">
                    <input type="submit" class="btn btn-info">

                </div>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>