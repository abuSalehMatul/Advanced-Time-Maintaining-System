<?php

use Faker\Generator as Faker;

$factory->define(App\Time::class, function (Faker $faker) {
    return [
        //
    ];
});
