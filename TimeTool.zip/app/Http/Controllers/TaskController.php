<?php

namespace App\Http\Controllers;

use App\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Hash;
use Session;
use Auth;
use App\User;
use App\Role;
use App\User_Image;
use App\Category;
use App\Record;

class TaskController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Task  $task
     * @return \Illuminate\Http\Response
     */
    public function show(Task $task)
    {
       $user=Session::get('user');
       $role=Session::get('role');
       $task=Task::where('creator',$user->id)->get();
       if($role->role==1){
            return view('back.project.view')->with('task',$task)->with('user',$user)->with('role',$role);
       }elseif($role->role==2){
            $record=Record::where('manager_id',$user->id)->get();
            return view('back.project.view')->with('task',$task)->with('record',$record)->with('role', $role)->with('user', $user);
       }elseif($role->role==3){
           $record=Record::where('admin',$user->id)->get();
            return view('back.project.view')->with('task', $task)->with('record', $record)->with('role',$role)->with('user',$user);
       }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Task  $task
     * @return \Illuminate\Http\Response
     */
    public function edit(Task $task)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Task  $task
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Task $task)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Task  $task
     * @return \Illuminate\Http\Response
     */
    public function destroy(Task $task)
    {
        //
    }
}
