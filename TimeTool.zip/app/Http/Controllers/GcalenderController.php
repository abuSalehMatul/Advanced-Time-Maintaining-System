<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GcalenderController extends Controller
{
    //
}
