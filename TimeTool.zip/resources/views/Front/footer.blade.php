 
 <style>
 .footer2{
     background: #a5a4a4;
     color: aliceblue;
     padding: 10px;
     height: 120px;

 }
 .footer2 ul{
     margin-left: 10px;
     font-weight: 700;
     color: aliceblue;
 }
.footer2 ul li a {
    color: #0F3A5D;
    float: right;
    margin-left: 45px;
    font-size: 20px;
}
.footer2 p{
    font-size: 12px;
    font-weight: 700;
    text-align: center;
    margin-left: 38%;

}
.footer2 small{
    color:blanchedalmond;
    font-weight: 600;
}
 </style>
 <div class="footer2">
   
    <ul class="footer__terms">
        <li> <a href="terms.html" ><li>Terms</li></a></li>
        <li> <a href="terms.html"><li>Terms</li></a></li>
        <li> <a href="terms.html"><li>Terms</li></a></li>
        <li> <a href="terms.html"><li>Terms</li></a></li>
        <li> <a href="terms.html"><li>Terms</li></a></li>

    </ul>
     <p style="float:left">All right reserved by
      © <script type="text/javascript"> document.write(new Date().getFullYear());</script> The TimeREC
    </p>
    <small style="float:right">Developed by <a href="https://salehmatul.com">Mtech</a></small>
  </div>