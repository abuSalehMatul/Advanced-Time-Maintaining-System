<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('test','UserController@test');
Auth::routes();


Route::get('/','PageController@index');
Route::post('/user_register','UserController@register');
Route::post( 'user_login','UserController@login');
Route::get('/logout_user', 'UserController@logout_user');

Route::group(['middleware' => 'auth'], function () {
    Route::get('/dashboard', 'UserController@dashboard')->name('dashboard'); 
    Route::get('/create_record','RecordController@form'); 
    Route::post( '/store_record','RecordController@store');
    Route::get( '/category', 'UserController@category');
    Route::get( '/add_category', 'UserController@add_category');
    Route::post( '/add_category','UserController@store_category');
    Route::get('/change_role/{id}','UserController@change_role');
    Route::get( '/projects','TaskController@show');
});