<?php $__env->startSection('content'); ?>
<style>
.off-div{
    margin-left:4px;
    padding:5px;
}
.description{
    border: 1px dotted wheat;
    box-shadow: 2px 3px whitesmoke;
    height: 100px;
   
    overflow: hidden;
}
.td{
    width: 10px;
}
</style>
    <div class="az-content-label mg-b-5">
        <div class="off-div">
            <div class="clearfix">
               <table>
                   <tr>
                       <td><button class="btn">As user</button></td>
                       <td><button class="btn">As manager</button></td>
                       <td><button class="btn">As Admin</button></td>
                   </tr>
               </table>
            </div>
            <div id="user">

            </div>
            <div id="manager">

            </div>
            <div id="admin">
                <?php if($record): ?>
                    <?php $__currentLoopData = $record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php
                          $pro=App\Task::where('id',$record->task_id)->get();
                        //   print($pro);
                        //   exit();
                      ?>
                      <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card record">
                            <table class="table table-borderless table-responsive">
                                <tr class="row">
                                    <td colspan="">
                                        <h4 style="border:1px dotted gold">
                                            <?php echo e($proj->name); ?>

                                        </h4>
                                        </td>
                                    <td class="td"></td>
                                    
                                    <?php
                                        $manager=App\User::where('id',$record->manager_id)->first();
                                        $admin=App\User::where('id',$record->admin)->first();
                                    ?>
                                    <td>
                                        <h5>
                                             <?php echo e($manager->name); ?>


                                            <span class="badge badge-success">Manager</span>
                                        </h5>
                                        <h6>
                                            <?php echo e($manager->email); ?>

                                        </h6>
                                       
                                    </td>
                                    <td class="td"></td>
                                  
                                    <td >
                                        <h5>
                                            <?php echo e($admin->name); ?>

                                             <span class="badge badge-success">Admin</span>
                                        </h5>
                                        <h6>
                                            <?php echo e($admin->email); ?>

                                        </h6>
                                        
                                    </td>
                                   
                                </tr>
                                <tr>
                                    <td>
                                        <div class="description">
                                            <h6 class="text-center" style="border:1px dotted blue">Description</h6>
                                              <?php echo e($proj->description); ?>

                                        </div>
                                      
                                    </td>
                                    <td>
                                        <div>
                                            <h6>numerof association</h6>
                                            <h6><button disabled="active">Mark as complete</button></h6>
                                            <h6><button disabled="disabled">See details</button></h6>
                                        </div>
                                        numerof association
                                    </td>
                                    <td>
                                        <input type="text" placeholder="Add note">
                                        <button disabled="">Submit</button>
                                    </td>
                                    <td></td>
                                </tr>
                                <tr>
                                     <td>
                                        <button disabled="" class="btn btn-info">Edit</button>
                                        <button disabled="" class="btn btn-danger float-right">Delete</button>
                                    </td>
                                    <td>
                                        <h6 class="float-right">last modified 1/2/2010</h6>
                                    </td>
                                </tr>
                            </table>
                        </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>