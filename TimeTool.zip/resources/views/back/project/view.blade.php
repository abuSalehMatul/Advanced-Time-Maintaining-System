@extends('back.master')
@section('content')
<style>
.off-div{
    margin-left:4px;
    padding:5px;
}
.description{
    border: 1px dotted wheat;
    box-shadow: 2px 3px whitesmoke;
    height: 100px;
   
    overflow: hidden;
}
.td{
    width: 10px;
}
</style>
    <div class="az-content-label mg-b-5">
        <div class="off-div">
            <div class="clearfix">
               <table>
                   <tr>
                       <td><button class="btn">As user</button></td>
                       <td><button class="btn">As manager</button></td>
                       <td><button class="btn">As Admin</button></td>
                   </tr>
               </table>
            </div>
            <div id="user">

            </div>
            <div id="manager">

            </div>
            <div id="admin">
                @if($record)
                    @foreach($record as $record)
                      @php
                          $pro=App\Task::where('id',$record->task_id)->get();
                        //   print($pro);
                        //   exit();
                      @endphp
                      @foreach($pro as $proj)
                        <div class="card record">
                            <table class="table table-borderless table-responsive">
                                <tr class="row">
                                    <td colspan="">
                                        <h4 style="border:1px dotted gold">
                                            {{$proj->name}}
                                        </h4>
                                        </td>
                                    <td class="td"></td>
                                    
                                    @php
                                        $manager=App\User::where('id',$record->manager_id)->first();
                                        $admin=App\User::where('id',$record->admin)->first();
                                    @endphp
                                    <td>
                                        <h5>
                                             {{$manager->name}}

                                            <span class="badge badge-success">Manager</span>
                                        </h5>
                                        <h6>
                                            {{$manager->email}}
                                        </h6>
                                       
                                    </td>
                                    <td class="td"></td>
                                  
                                    <td >
                                        <h5>
                                            {{$admin->name}}
                                             <span class="badge badge-success">Admin</span>
                                        </h5>
                                        <h6>
                                            {{$admin->email}}
                                        </h6>
                                        
                                    </td>
                                   
                                </tr>
                                <tr>
                                    <td>
                                        <div class="description">
                                            <h6 class="text-center" style="border:1px dotted blue">Description</h6>
                                              {{$proj->description}}
                                        </div>
                                      
                                    </td>
                                    <td>
                                        <div>
                                            <h6>numerof association</h6>
                                            <h6><button disabled="active">Mark as complete</button></h6>
                                            <h6><button disabled="disabled">See details</button></h6>
                                        </div>
                                        numerof association
                                    </td>
                                    <td>
                                        <input type="text" placeholder="Add note">
                                        <button disabled="">Submit</button>
                                    </td>
                                    <td></td>
                                </tr>
                                <tr>
                                     <td>
                                        <button disabled="" class="btn btn-info">Edit</button>
                                        <button disabled="" class="btn btn-danger float-right">Delete</button>
                                    </td>
                                    <td>
                                        <h6 class="float-right">last modified 1/2/2010</h6>
                                    </td>
                                </tr>
                            </table>
                        </div>
                       @endforeach 
                    @endforeach
                @endif
            </div>
        </div>
    </div>

@endsection