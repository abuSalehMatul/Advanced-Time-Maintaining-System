<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User_Image extends Model
{
    protected $table ='images';
}
