<?php $__env->startSection('content'); ?>
<div class="card row " style="margin-left:5px">
    <div class="well table-responsive">
        <h3 class="text-justify float-left">Categories</h3>
        <a href="<?php echo e(url('add_category')); ?>" class="btn btn-info float-right">Add Category</a>
        <table class="table table-striped">
            <tr>
                <td style="font-weight:700;font-size:1.2rem;">
                    SI
                </td>
                <td style="font-weight:700;font-size:1.2rem;">
                    Category Name
                </td>
            </tr>
            <?php
                $category=App\Category::all();
                $i=1;
            ?>
           <?php if($category): ?>
           <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($category->name); ?></td>
                </tr>
                <?php
                    $i++;
                ?>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
           <?php endif; ?>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>